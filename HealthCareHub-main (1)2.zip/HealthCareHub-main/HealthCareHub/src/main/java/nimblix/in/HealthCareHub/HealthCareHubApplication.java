package nimblix.in.HealthCareHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCareHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthCareHubApplication.class, args);
	}

}
