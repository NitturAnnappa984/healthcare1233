package nimblix.in.HealthCareHub.serviceImpl;

public class DoctorServiceImpl {
}
