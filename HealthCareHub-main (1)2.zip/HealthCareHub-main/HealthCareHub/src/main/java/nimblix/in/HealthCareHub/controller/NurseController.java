package nimblix.in.HealthCareHub.controller;

public class NurseController {
}
